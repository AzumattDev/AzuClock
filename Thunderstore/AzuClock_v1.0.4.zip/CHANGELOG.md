﻿| `Version` | `Update Notes`                                                                                                    |
|-----------|-------------------------------------------------------------------------------------------------------------------|
| 1.0.4     | - No change to code, bumping version to show I cared to look at the mod after Valheim's Bog Witch update          |
| 1.0.3     | - No change to code, bumping version to show I cared to look at the mod after Valheim's latest update (0.217.46). |
| 1.0.2     | - No change to code, bumping version to show I cared to look at the mod after Valheim's latest update.            |
| 1.0.1     | - Add an explicit configuration for displaying Realtime                                                           |
| 1.0.0     | - Initial Release                                                                                                 |